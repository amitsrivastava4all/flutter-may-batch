import 'dart:async';

import 'package:chat_app/user_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Crud {
  FirebaseFirestore firestore = FirebaseFirestore.instance;
  CollectionReference users = FirebaseFirestore.instance.collection('users');
  Future<String> add(Map<String, String> map) async {
    DocumentReference d = await users.add(map);
    return d.id;
  }

  Stream<List<UserModel>> getData() {
    List<UserModel> list = [];

    Stream<QuerySnapshot> stream = getStreamData();
    print("Rec Stream........$stream");

    Stream<List<UserModel>> s = stream.map((QuerySnapshot snapshot) {
      return snapshot.docs
          .map((e) {
            UserModel uu =
                UserModel.takeUser(e['email'], e['name'], e['photo']);
            print("UserModel Object created.... and added in list $list");

            print(uu.email + " " + uu.name);
            return uu;
          })
          .toList()
          .toList();
    });

    print("@@@@Final Stream is $s");

    print("!!!!!!!!!!!! List is $list");
    return s;
  }

  Stream<QuerySnapshot> getStreamData() {
    print("Stream.####");

    Stream<QuerySnapshot> stream = users.snapshots();
    print("Stream.#### $stream");
    return stream;

    // Stream<UserModel> s =  stream.map((event) => event.docs
    //       .map((e) => UserModel.takeUser(e['email'], e['name'], e['photo']));
    // }).toList().asStream();
  }
}
