import 'package:chat_app/auth.dart';
import 'package:chat_app/crud.dart';
import 'package:chat_app/user_model.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  _doLogin() async {
    UserCredential userCredential = await signInWithGoogle();
    print("user info is ");
    print(userCredential.user);
    User user = userCredential.user!;
    Map<String, String> map = {
      "email": user.email!,
      "photo": user.photoURL!,
      "googleid": user.uid,
      "name": user.displayName!
    };
    try {
      var id = await crud.add(map);
      msg = "Record Added " + id;
    } catch (err) {
      msg = "Some Error Occur $err";
      print("Error in Add ");
      print(err);
    }
    setState(() {});
  }

  Crud crud = Crud();
  String msg = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Login')),
      body: Column(
        children: [
          Text(
            msg,
            style: TextStyle(fontSize: 40),
          ),
          ElevatedButton(
              onPressed: () {
                _doLogin();
              },
              child: Text('Login')),
          Container(
            height: 200,
            child: StreamBuilder<List<UserModel>>(
              builder: (c, snapshot) {
                if (!snapshot.hasData) {
                  return Center(
                    child: CircularProgressIndicator(),
                  );
                } else if (snapshot.hasError) {
                  print("Error During Load...");

                  return Text('Some Error Occur ');
                }
                return ListView.builder(
                    itemBuilder: (ctx, int index) {
                      return ListTile(
                        title: Text(snapshot.data![index].email),
                        subtitle: Text(snapshot.data![index].name),
                        leading: Image.network(snapshot.data![index].photo),
                      );
                    },
                    itemCount: snapshot.data?.length);
              },
              stream: crud.getData(),
            ),
          )
        ],
      ),
    );
  }
}
