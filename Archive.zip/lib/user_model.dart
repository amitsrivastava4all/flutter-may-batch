class UserModel {
  late String email;
  late String name;
  late String photo;
  UserModel() {}
  UserModel.takeUser(this.email, this.name, this.photo);
}
