import 'dart:developer';

import 'package:flutter_bloc/flutter_bloc.dart';

class CounterCubit extends Cubit<int> {
  CounterCubit() : super(0) {} // it means 0 value is set to the state
  // super is used to call parent class constructor
  plus() {
    emit(state + 1);
  }

  minus() {
    emit(state - 1);
  }
}
