import 'package:bloc_demo/cubit/counter_cubit.dart';
import 'package:bloc_demo/pages/result.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class CounterPage extends StatelessWidget {
  late BuildContext ctx;

  _plus() {
    CounterCubit obj =
        BlocProvider.of<CounterCubit>(ctx); // Access the Cubit Object
    obj.plus(); // Call the Plus Method of Counter Cubit
  }

  _minus() {
    CounterCubit obj =
        BlocProvider.of<CounterCubit>(ctx); // Access the Cubit Object
    obj.minus();
  }

  @override
  Widget build(BuildContext context) {
    ctx = context;
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(title: Text('Counter App')),
      body: Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                  onPressed: () {
                    _plus();
                  },
                  child: Text('Plus')),
              SizedBox(width: 20),
              ElevatedButton(
                  onPressed: () {
                    _minus();
                  },
                  child: Text('Minus'))
            ],
          ),
          SizedBox(
            height: 100,
          ),
          Result()
        ]),
      ),
    );
  }
}
