import 'package:bloc_demo/cubit/counter_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

abstract class MathEvent {}

class PlusEvent extends MathEvent {}

class MinusEvent extends MathEvent {}

class CounterBloc extends Bloc<MathEvent, CounterState> {
  CounterBloc() : super(CounterState(0, 0, 0)) {
    // Event Listener Register
    on<PlusEvent>((event, emit) =>
        emit(CounterState(state.x + 1, state.y + 2, state.z + 3)));
    on<MinusEvent>((event, emit) =>
        emit(CounterState(state.x - 1, state.y - 2, state.z - 3)));
  }
}
