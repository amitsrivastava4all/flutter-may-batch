import 'dart:developer';

class CounterState {
  late int x;
  late int y;
  late int z;
  CounterState(int x, int y, int z) {
    this.x = x;
    this.y = y;
    this.z = z;
  }
}
