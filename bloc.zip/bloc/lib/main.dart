import 'package:bloc_demo/bloc/counter_bloc.dart';
import 'package:bloc_demo/cubit/counter_cubit.dart';
import 'package:bloc_demo/pages/counter_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

void main() {
  // Bloc Call Code
  runApp(MaterialApp(
      home: MultiBlocProvider(
    providers: [
      //BlocProvider(create: create)
      BlocProvider<CounterBloc>(
        lazy: true,
        create: (ctx) =>
            CounterBloc(), // Bloc Object created Here and supply to the CounterPageWidget
      )
    ],
    child: CounterPage(),
  )));

  // Cubit Call code
  // runApp(MaterialApp(
  //     home: BlocProvider<CounterCubit>(
  //   create: (ctx) =>
  //       CounterCubit(), // Cubit Object created Here and supply to the CounterPageWidget
  //   child: CounterPage(),
  // )));
}
