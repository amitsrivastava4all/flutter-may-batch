import 'package:bloc_demo/bloc/counter_bloc.dart';
import 'package:bloc_demo/cubit/counter_cubit.dart';
import 'package:bloc_demo/pages/result.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class CounterPage extends StatelessWidget {
  late BuildContext ctx;

  _plus() {
    //CounterBloc obj2 = ctx.read<CounterBloc>();
    CounterBloc obj = BlocProvider.of<CounterBloc>(ctx,
        listen: true); // Access the Cubit Object
    // Bloc Trigger the Event
    obj.add(PlusEvent());
  }

  // _plus() {
  //   CounterCubit obj =
  //       BlocProvider.of<CounterCubit>(ctx); // Access the Cubit Object
  //   obj.plus(5); // Call the Plus Method of Counter Cubit
  // }

  _minus() {
    CounterBloc obj =
        BlocProvider.of<CounterBloc>(ctx); // Access the Cubit Object
    obj.add(MinusEvent());
  }

  // _minus() {
  //   CounterCubit obj =
  //       BlocProvider.of<CounterCubit>(ctx); // Access the Cubit Object
  //   obj.minus();
  // }

  @override
  Widget build(BuildContext context) {
    ctx = context;
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(title: Text('Counter App')),
      body: Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                  onPressed: () {
                    _plus();
                  },
                  child: Text('Plus')),
              SizedBox(width: 20),
              ElevatedButton(
                  onPressed: () {
                    _minus();
                  },
                  child: Text('Minus'))
            ],
          ),
          SizedBox(
            height: 100,
          ),
          Result()
        ]),
      ),
    );
  }
}
