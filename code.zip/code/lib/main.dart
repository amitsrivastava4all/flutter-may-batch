import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MaterialApp(
      //home: SafeArea(child: Text('Hello Flutter')),
      home: Scaffold(
    appBar: PreferredSize(
      preferredSize: Size.fromHeight(200),
      child: AppBar(
        flexibleSpace: Image.network(
            'https://iconarchive.com/download/i107368/google/noto-emoji-animals-nature/22261-panda-face.ico',
            fit: BoxFit.cover),
        elevation: 10,
        shadowColor: Colors.white,
        leading: Icon(Icons.menu),

        backgroundColor: Colors.orange,
        actions: const [
          Padding(
            padding: EdgeInsets.all(10),
            child: Icon(
              Icons.delete,
              size: 30,
              color: Colors.green,
            ),
          ),
          Padding(
              padding: EdgeInsets.only(right: 20),
              child: Icon(Icons.more_vert)),
          // SizedBox(
          //   width: 20,
          // )
        ],
        // centerTitle: true,
        //title: const Text('My First App'),
        // title: Image.network(
        // 'https://iconarchive.com/download/i107368/google/noto-emoji-animals-nature/22261-panda-face.ico',
        // fit: BoxFit.cover),
      ),
    ),
    body: Container(
      width: 300,
      height: 300,
      decoration: BoxDecoration(
          image: DecorationImage(
              image: NetworkImage(
                  scale: 1,
                  'https://c.tenor.com/XE1tU4Ek72YAAAAM/hulk-roar.gif')),
          boxShadow: [
            BoxShadow(color: Colors.white, spreadRadius: 10, blurRadius: 10)
          ],
          //color: Colors.yellow,
          shape: BoxShape.circle,
          gradient: RadialGradient(
              //   stops: [
              //   0.3,
              //   0.5,
              //   0.3
              // ],
              // begin: Alignment.topLeft,
              // end: Alignment.bottomRight,
              colors: [
                Color(0Xefac36),
                Colors.redAccent,
                // Colors.greenAccent,
                Colors.yellowAccent
              ]),
          border: Border.all(
              color: Colors.blue, width: 5, style: BorderStyle.solid)),
      margin: EdgeInsets.only(top: 140, left: 20),
      padding: EdgeInsets.all(50),

      // child: Text(
      //   'Hello Flutter',
      //   style: GoogleFonts.pacifico(fontSize: 40),
      // ),
      // color: Colors.yellowAccent,
    ),
    floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    floatingActionButton: FloatingActionButton(
      backgroundColor: Colors.blueGrey,
      onPressed: () {},
      child: Icon(
        Icons.call,
        color: Colors.amberAccent,
      ),
    ),
    backgroundColor: Colors.black,
  )));
}
