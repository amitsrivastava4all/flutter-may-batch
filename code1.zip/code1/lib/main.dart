import 'package:flutter/material.dart';
import 'package:navdemo/pages/one.dart';
import 'package:navdemo/routes/routes.dart';

void main() {
  runApp(MaterialApp(
    onGenerateRoute: getGenRoutes,
    // routes: getRoutes(),
    initialRoute: "/",
    // home: One(),
  ));
}
