import 'package:flutter/material.dart';
import 'package:navdemo/pages/two.dart';

class One extends StatefulWidget {
  const One({Key? key}) : super(key: key);

  @override
  State<One> createState() => _OneState();
}

class _OneState extends State<One> {
  _moveToSecond() {
    //Navigator.of(context).push(MaterialPageRoute(builder: (_) => Two(userid)));
    Navigator.of(context)
        .pushNamed("/two", arguments: {'userid': userid, 'name': 'Ram Kumar'});
  }

  String userid = "amit";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('First Screen')),
      body: Container(
          child: Center(
        child: ElevatedButton(
          onPressed: () {
            _moveToSecond();
          },
          child: Text('Move to Second'),
        ),
      )),
    );
  }
}
