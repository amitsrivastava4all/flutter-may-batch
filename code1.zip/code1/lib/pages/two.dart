import 'package:flutter/material.dart';

class Two extends StatefulWidget {
  // String userid;
  late Map<String, dynamic> args;
  // Two(args) {
  //   this.args = args;
  // }
  Two(this.args);

  @override
  State<Two> createState() => _TwoState();
}

class _TwoState extends State<Two> {
  _moveToThird() {
    Navigator.of(context).pushNamed("/third");
  }

  @override
  Widget build(BuildContext context) {
    // Map<String, dynamic> args =
    //   ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>;
    return Scaffold(
      appBar: AppBar(
          title: Text('Second Screen ' +
              widget.args['userid'] +
              " " +
              widget.args['name'])),
      body: Container(
        color: Colors.yellow,
        child: Center(
            child: ElevatedButton(
          onPressed: () {
            _moveToThird();
          },
          child: Text('Third'),
        )),
      ),
    );
  }
}
