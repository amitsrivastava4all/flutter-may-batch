import 'package:flutter/material.dart';
import 'package:navdemo/pages/one.dart';
import 'package:navdemo/pages/third.dart';
import 'package:navdemo/pages/two.dart';

// getRoutes() {
//   return {"/": (_) => One(), "/second": (_) => Two(), "/third": (_) => Third()};
// }

Route<dynamic> getGenRoutes(RouteSettings settings) {
  if (settings.name == '/') {
    return MaterialPageRoute(builder: (_) => One());
  } else if (settings.name == '/two') {
    Map<String, dynamic> args = settings.arguments as Map<String, dynamic>;
    return MaterialPageRoute(builder: (_) => Two(args));
  } else if (settings.name == '/three') {
    return MaterialPageRoute(builder: (_) => Third());
  } else {
    return MaterialPageRoute(builder: (_) => Third());
  }
}
