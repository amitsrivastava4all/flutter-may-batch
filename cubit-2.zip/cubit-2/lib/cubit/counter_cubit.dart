import 'dart:developer';

import 'package:bloc_demo/cubit/counter_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

// class CounterCubit extends Cubit<int> {
//   CounterCubit() : super(0) {} // it means 0 value is set to the state
//   // super is used to call parent class constructor
//   plus() {
//     emit(state + 1);
//   }

//   minus() {
//     emit(state - 1);
//   }
// }
// Complex Type
class CounterCubit extends Cubit<CounterState> {
  CounterCubit()
      : super(CounterState(0, 0, 0)) {} // it means 0 value is set to the state
  // super is used to call parent class constructor
  plus(int z) {
    emit(CounterState(state.x + 1, state.y + 2, state.z + 3 * z));
  }

  minus() {
    emit(CounterState(state.x - 1, state.y - 2, state.z - 3));
  }
}
