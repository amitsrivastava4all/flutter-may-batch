import 'package:bloc_demo/cubit/counter_cubit.dart';
import 'package:bloc_demo/pages/counter_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

void main() {
  runApp(MaterialApp(
      home: BlocProvider<CounterCubit>(
    create: (ctx) =>
        CounterCubit(), // Cubit Object created Here and supply to the CounterPageWidget
    child: CounterPage(),
  )));
}
