import 'package:bloc_demo/cubit/counter_cubit.dart';
import 'package:bloc_demo/cubit/counter_state.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

// class Result extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return BlocBuilder<CounterCubit, int>(
//       builder: (ctx, state) {
//         return Text(
//           'Output $state',
//           style: TextStyle(fontSize: 40),
//         );
//       },
//     );
//   }
// }

// Complex
class Result extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CounterCubit, CounterState>(
      builder: (ctx, state) {
        return Text(
          'Output ${state.x} ${state.y} ${state.z} ',
          style: TextStyle(fontSize: 40),
        );
      },
    );
  }
}
