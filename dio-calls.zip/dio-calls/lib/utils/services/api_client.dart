import 'package:dio/dio.dart';

class ApiClient {
  static ApiClient _client = ApiClient._();
  ApiClient._() {}
  Dio _dio = Dio();
  static ApiClient getInstance() {
    return _client;
  }

  Future<Response> getData(URL) {
    return _dio.get(URL);
  }

  Future<Response> post(URL, Map<String, dynamic> json) {
    return _dio.post(URL, data: json);
  }
}
