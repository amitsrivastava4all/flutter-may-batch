import 'package:flame_application/widgets/custom_textfield.dart';
import 'package:flame_application/widgets/flame_options.dart';
import 'package:flutter/material.dart';

class FlamePage extends StatefulWidget {
  const FlamePage({Key? key}) : super(key: key);

  @override
  State<FlamePage> createState() => _FlamePageState();
}

class _FlamePageState extends State<FlamePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
          child: Column(
        children: [
          CustomTextField('Male', Icons.male),
          CustomTextField('Female', Icons.female),
          Container(
            margin: EdgeInsets.only(right: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                ElevatedButton(
                    style: ButtonStyle(
                        backgroundColor:
                            MaterialStateProperty.all(Colors.deepOrange)),
                    onPressed: () {},
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        'Compute',
                        style: TextStyle(fontSize: 20),
                      ),
                    ))
              ],
            ),
          ),
          FlameOptions()
        ],
      )),
      appBar: AppBar(
          backgroundColor: Colors.teal,
          centerTitle: true,
          title: Text('Flame App')),
    );
  }
}
