class FlameOperations {
  Map<String, int> map = {};
  int getCount(String maleName, String femaleName) {
    int count = 0;
    _getMap(maleName, true);
    _getMap(femaleName, false);

    for (String key in map.keys) {
      int val = map[key]!;
      val = val.abs();
      if (val > 0) {
        count = count + val;
      }
    }
    return count;
  }

  Map<String, int> _getMap(String name, bool plus) {
    List<String> str = name.split("");
    for (String s in str) {
      if (map.containsKey(s)) {
        int val = map[s]!;

        map[s] = plus ? ++val : --val;
      } else {
        map[s] = plus ? 1 : -1;
      }
    }
    return map;
  }

  // void main() {
  //   String name = "ravina";
  //   String name2 = "ramm";
  //   getMap(name, true);
  //   print(map);
  //   getMap(name2, false);
  //   print(map);
  //   int count = 0;

  //   for (String key in map.keys) {
  //     int val = map[key]!;
  //     val = val.abs();
  //     if (val > 0) {
  //       count = count + val;
  //     }
  //   }
  //   print("Count $count");
  // }
}
