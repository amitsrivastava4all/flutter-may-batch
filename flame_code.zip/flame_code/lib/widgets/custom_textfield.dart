import 'package:flutter/material.dart';

class CustomTextField extends StatelessWidget {
  String label;
  IconData icon;

  CustomTextField(this.label, this.icon);
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(10),
      child: TextField(
        decoration: InputDecoration(
            label: Text(label),
            hintText: 'Type For $label Name',
            prefixIcon: Icon(icon),
            border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(10))),
      ),
    );
  }
}
