import 'dart:ui';

import 'package:flutter/material.dart';

class FlameOptions extends StatelessWidget {
  const FlameOptions({Key? key}) : super(key: key);

  _getStyle({Color color = Colors.black}) {
    return TextStyle(fontSize: 20, color: color);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          'F - Friend',
          style: _getStyle(),
        ),
        Text(
          'L - Love',
          style: _getStyle(),
        ),
        Text(
          'A - Affication',
          style: _getStyle(),
        ),
        Text(
          'M - Marriage',
          style: _getStyle(),
        ),
        Text(
          'E - Enemy',
          style: _getStyle(),
        ),
        Text(
          'S - Sister',
          style: _getStyle(),
        )
      ],
    );
  }
}
