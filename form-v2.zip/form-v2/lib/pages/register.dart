import 'package:flutter/material.dart';
import '/widgets/datepicker.dart';
import '/widgets/radiobutton.dart';
import '/widgets/checkbox.dart';
import '/widgets/dropdown.dart';

import '/utils/validations.dart';
import '/widgets/textbox.dart';

class Register extends StatefulWidget {
  const Register({Key? key}) : super(key: key);

  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  final formKey = GlobalKey<FormState>();
  _submitForm() {
    var formState = formKey.currentState;
    if (formState != null && formState.validate()) {
      print("Form is Valid ");
    } else {
      print("Form is Not Valid");
    }
  }

  String emailError = "";
  String passwordError = "";
  String nameError = "";

  _emailValidationOnChange(String value) {
    emailError = Validation.isCorrectEmail(value) ?? "";
    setState(() {});
  }

  _passwordValidationOnChange(String value) {
    passwordError = Validation.isCorrectPassword(value) ?? "";
    setState(() {});
  }

  _nameValidationOnChange(String value) {
    nameError = Validation.isCorrectName(value) ?? "";
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Register Form'),
        centerTitle: true,
        backgroundColor: Colors.redAccent,
      ),
      body: SingleChildScrollView(
        child: Form(
          //autovalidateMode: AutovalidateMode.always,
          key: formKey,
          child: Column(children: [
            TextBox(
              errorMessage: emailError,
              validationOnChange: _emailValidationOnChange,
              validationFn: Validation.isCorrectEmail,
              label: 'Email',
              iconData: Icons.email,
            ),
            TextBox(
              hideText: true,
              errorMessage: passwordError,
              validationOnChange: _passwordValidationOnChange,
              validationFn: Validation.isCorrectPassword,
              label: 'Password',
              iconData: Icons.password,
            ),
            TextBox(
              errorMessage: nameError,
              validationOnChange: _nameValidationOnChange,
              validationFn: Validation.isCorrectName,
              label: 'Name',
              iconData: Icons.verified_user,
            ),
            DropDownBox(),
            CheckBoxControl(),
            RadioButtonControl(),
            DatePickerControl(),
            ElevatedButton(
              onPressed: () {
                _submitForm();
              },
              child: Text(
                'Register',
                style: TextStyle(fontSize: 20),
              ),
              style: ButtonStyle(
                  padding:
                      MaterialStateProperty.resolveWith<EdgeInsetsGeometry>(
                    (Set<MaterialState> states) {
                      return EdgeInsets.all(20);
                    },
                  ),
                  backgroundColor:
                      MaterialStateProperty.all(Colors.green.shade600)),
            )
          ]),
        ),
      ),
    );
  }
}
