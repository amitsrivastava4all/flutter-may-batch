// Now my class is become a Singleton class

class DropDownRepo {
  static DropDownRepo _dropDown = DropDownRepo._(); // Object create
  DropDownRepo._() {} // private constructor
  static DropDownRepo getInstance() {
    return _dropDown; // return the instance
  }

  List<String> getDropDownList() {
    return ["select", "India", "SriLanka", "USA", "UK"];
  }
}
