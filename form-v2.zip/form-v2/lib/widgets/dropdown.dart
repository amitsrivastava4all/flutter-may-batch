import 'package:flutter/material.dart';
import '/repository/dropdown.dart';

class DropDownBox extends StatefulWidget {
  const DropDownBox({Key? key}) : super(key: key);

  @override
  State<DropDownBox> createState() => _DropDownBoxState();
}

class _DropDownBoxState extends State<DropDownBox> {
  String currentCountry = "India";
  DropDownRepo _dropDownRepo = DropDownRepo.getInstance();
  List<DropdownMenuItem<String>> _getCountry() {
    List<String> country = _dropDownRepo.getDropDownList();
    // List of String convert into DropDownMenuItem with the help of map function
    List<DropdownMenuItem<String>> menuList = country
        .map((String singleCountry) =>
            DropdownMenuItem(child: Text(singleCountry), value: singleCountry))
        .toList();
    return menuList;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(10),
      child: DropdownButtonFormField(
        validator: (String? value) {
          print("Validation Call...");
          if (value == "select") {
            return "Choose a Country";
          }
          return null;
        },
        value: currentCountry,
        dropdownColor: Colors.greenAccent,

        decoration: InputDecoration(
            fillColor: Colors.tealAccent,
            filled: true,
            border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(10))),
        // enabledBorder:
        //   OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        onChanged: (String? country) {
          currentCountry = country!;
          setState(() {});
        },
        items: _getCountry(),
      ),
    );
  }
}
