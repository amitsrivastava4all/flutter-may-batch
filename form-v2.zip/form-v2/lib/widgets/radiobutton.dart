import 'package:flutter/material.dart';

class RadioButtonControl extends StatefulWidget {
  const RadioButtonControl({Key? key}) : super(key: key);

  @override
  State<RadioButtonControl> createState() => _RadioButtonControlState();
}

class _RadioButtonControlState extends State<RadioButtonControl> {
  int groupValue = -1;
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          RadioListTile<int>(
            title: Text('Male'),
            value: 1,
            groupValue: groupValue,
            onChanged: (int? value) {
              groupValue = value!;
              setState(() {});
            },
          ),
          RadioListTile<int>(
            title: Text('Female'),
            value: 2,
            groupValue: groupValue,
            onChanged: (int? value) {
              groupValue = value!;
              setState(() {});
            },
          )
        ],
      ),
    );
  }
}
