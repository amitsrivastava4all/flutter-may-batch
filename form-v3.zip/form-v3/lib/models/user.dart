class User {
  late String email;
  late String password;
  late String name;
  late String city;
  User() {}
  User.takeUser(this.email, this.password, this.name, this.city);
}
