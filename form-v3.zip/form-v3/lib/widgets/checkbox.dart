import 'package:flutter/material.dart';

class CheckBoxControl extends StatefulWidget {
  const CheckBoxControl({Key? key}) : super(key: key);

  @override
  State<CheckBoxControl> createState() => _CheckBoxControlState();
}

class _CheckBoxControlState extends State<CheckBoxControl> {
  bool currentValue = false;
  @override
  Widget build(BuildContext context) {
    return Container(
      child: FormField(
          validator: (bool? value) {},
          builder: (FormFieldState<dynamic> field) {
            return CheckboxListTile(
              onChanged: (bool? value) {
                currentValue = value!;
                setState(() {});
              },
              value: currentValue,
              controlAffinity: ListTileControlAffinity.leading,
              title: Text('I Agree'),
            );
          }),
    );
  }
}
