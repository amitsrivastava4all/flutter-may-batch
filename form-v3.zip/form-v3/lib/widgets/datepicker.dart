import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class DatePickerControl extends StatefulWidget {
  const DatePickerControl({Key? key}) : super(key: key);

  @override
  State<DatePickerControl> createState() => _DatePickerControlState();
}

class _DatePickerControlState extends State<DatePickerControl> {
  _displayDatePicker() async {
    DateTime? dateTime = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(1900),
        lastDate: DateTime(2050));
    //tc.text = dateTime.toString();
    DateFormat df = DateFormat('dd-MM-yy');
    tc.text = df.format(dateTime!);
  }

  TextEditingController tc = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(10),
      child: TextFormField(
        controller: tc,
        decoration: InputDecoration(
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
            suffixIcon: IconButton(
              onPressed: () {
                _displayDatePicker();
              },
              icon: Icon(Icons.calendar_today),
            )),
      ),
    );
  }
}
