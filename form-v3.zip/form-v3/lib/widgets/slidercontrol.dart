import 'package:flutter/material.dart';

class SliderControl extends StatefulWidget {
  const SliderControl({Key? key}) : super(key: key);

  @override
  State<SliderControl> createState() => _SliderControlState();
}

class _SliderControlState extends State<SliderControl> {
  double val = 1;
  double val2 = 2;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        RangeSlider(
          divisions: 5,
          labels: RangeLabels(val.toInt().toString(), val2.toInt().toString()),
          activeColor: Colors.green,
          inactiveColor: Colors.red,
          values: RangeValues(val, val2),

          //thumbColor: Colors.orangeAccent,
          min: 1,
          max: 10,
          onChanged: (RangeValues values) {
            val = values.start;
            val2 = values.end;
            setState(() {});
          },
          //value: val,
          // onChanged: (double currentValue) {
          //   val = currentValue;
          //   setState(() {});
          // }
        ),
        Text(
          "${val.toInt()} and ${val2.toInt()}",
          style: TextStyle(fontSize: 20),
        )
      ],
    );
  }
}
