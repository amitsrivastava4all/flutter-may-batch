import 'package:flutter/material.dart';

import '../models/user.dart';

class TextBox extends StatelessWidget {
  String label;
  IconData iconData;
  Function validationFn;
  Function validationOnChange;
  String errorMessage;
  bool hideText;
  User model;
  TextBox(
      {required this.label,
      required this.model,
      required this.iconData,
      required this.validationFn,
      required this.validationOnChange,
      required this.errorMessage,
      this.hideText = false});

  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.all(15),
        child: TextFormField(
          obscureText: hideText,
          onChanged: (String? value) {
            validationOnChange(value);
          },
          onSaved: (String? val) {
            if (label.toLowerCase() == "email") {
              model.email = val!;
            } else if (label.toLowerCase() == "password") {
              model.password = val!;
            } else if (label.toLowerCase() == "name") {
              model.name = val!;
            }
          },
          validator: (String? value) {
            return validationFn(value);
            // Show the Message of the Validation (Failure) return a String
            // If no Failure so return null
          },
          decoration: InputDecoration(
              errorText: errorMessage,
              focusedErrorBorder:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
              errorStyle: TextStyle(
                  fontStyle: FontStyle.italic,
                  color: Colors.pinkAccent,
                  fontSize: 14,
                  fontWeight: FontWeight.bold),
              prefixIcon: Icon(iconData),
              hintText: 'Type $label Here',
              label: Text(label),
              border:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(20))),
        ));
  }
}
