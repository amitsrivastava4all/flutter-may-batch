import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class TimerPickerControl extends StatefulWidget {
  const TimerPickerControl({Key? key}) : super(key: key);

  @override
  State<TimerPickerControl> createState() => _TimerPickerControlState();
}

class _TimerPickerControlState extends State<TimerPickerControl> {
  TextEditingController tc = TextEditingController();
  _displayTimePicker() async {
    TimeOfDay? time =
        await showTimePicker(context: context, initialTime: TimeOfDay.now());
    //tc.text = "${time?.hour}:${time?.minute}";
    DateFormat df = DateFormat('hh:mm:ss aaa');
    print("time is $time");
    if (time != null) {
      DateTime dt = DateFormat.jm().parse(time.format(context).toString());
      String formattedTime = df.format(dt);
      tc.text = formattedTime;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(10),
      child: TextFormField(
        controller: tc,
        decoration: InputDecoration(
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
            suffixIcon: IconButton(
              onPressed: () {
                _displayTimePicker();
              },
              icon: Icon(Icons.timer),
            )),
      ),
    );
  }
}
