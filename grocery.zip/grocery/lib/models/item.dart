class Item {
  String title;
  double price;
  String image;
  String desc;
  int rating;

  Item(
      {required this.title,
      required this.price,
      required this.image,
      required this.desc,
      required this.rating});
}
