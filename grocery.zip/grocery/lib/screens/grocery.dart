import 'package:firstapp/services/item-operations.dart';
import 'package:firstapp/widgets/header.dart';
import 'package:firstapp/widgets/itemrow.dart';
import 'package:flutter/material.dart';

import '../widgets/item.dart';
import '../models/item.dart' as modelItem;

class Grocery extends StatelessWidget {
  List<Widget> _showFruits() {
    ItemOperations itemOperations = ItemOperations();
    List<modelItem.Item> itemList = itemOperations.read();
    // itemList contains all the items
    // we traverse items one by one using map function
    // map function give a single item object
    // this object we give to Item widget so one Item will be show on screen
    List<Widget> items = itemList
        .map((singleItemObject) => Item(
              name: singleItemObject.title,
              image: singleItemObject.image,
            ))
        .toList();
    return items;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.grey.shade300,
        appBar: PreferredSize(
          child: Header(
            title: "Fruit and Vegetable",
            color: Colors.pink,
          ),
          preferredSize: Size.fromHeight(70),
        ),
        body: Container(
            // child: Column(children: [ItemRow(), ItemRow(), ItemRow()]),
            child: Column(
          children: _showFruits(),
        ))
        //body: ,
        );
  }
}
