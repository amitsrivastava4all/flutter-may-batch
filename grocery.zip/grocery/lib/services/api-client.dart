const String URL =
    "https://raw.githubusercontent.com/wedeploy-examples/supermarket-web-example/master/products.json";
// Here we call the Backend api