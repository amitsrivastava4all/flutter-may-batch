// Item All Operations will be written Here
// CRUD
import '../models/item.dart';

class ItemOperations {
  List<Item> read() {
    return _prepareFakeData();
    // Call the ApiClient
    // We Prepare a Fake Data
  }

  _prepareFakeData() {
    return [
      Item(
          title: 'Apple',
          price: 50,
          desc: 'Kashmir Apple',
          rating: 5,
          image:
              'https://usapple.org/wp-content/uploads/2019/10/apple-pink-lady.png'),
      Item(
          title: 'Banana',
          price: 50,
          desc: 'Delhi',
          rating: 5,
          image:
              'https://upload.wikimedia.org/wikipedia/commons/thumb/6/69/Banana.png/800px-Banana.png'),
      Item(
          title: 'Orange',
          price: 150,
          desc: 'Delhi',
          rating: 5,
          image: 'https://www.realfruitpower.com/images/real_story/orange2.png')
    ];
  }
}
