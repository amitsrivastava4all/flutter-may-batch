import 'package:flutter/material.dart';

class Header extends StatelessWidget {
  Color color;
  String title;
  Header(
      {this.color = Colors.green, required this.title}); // UnNamed Constructor
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return AppBar(
      centerTitle: true,
      leading: Icon(Icons.menu),
      title: Text(title),
      backgroundColor: color,
    );
  }
}
