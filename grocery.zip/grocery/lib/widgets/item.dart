import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class Item extends StatelessWidget {
  double width;
  double height;
  String name;
  String image;
  Item(
      {required this.name,
      required this.image,
      this.width = 100,
      this.height = 100});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Image.network(image),
      margin: EdgeInsets.all(40),
      width: width,
      height: height,
      decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [BoxShadow(color: Colors.black, blurRadius: 5)]),
    );
  }
}
