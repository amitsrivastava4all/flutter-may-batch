import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:reactive_forms_example/models/person.dart';
import 'package:reactive_forms_example/pages/register.dart';

void main() async {
  // Initalize the Hive
  await Hive.initFlutter();
  // Register the Adapter
  Hive.registerAdapter(PersonAdapter());
  // open the Box
  Box<Person> box = await Hive.openBox('persons');
  runApp(MaterialApp(home: Register(box)));
}
