import 'package:flutter/material.dart';
import 'package:news_app/pages/all_news.dart';

void main() {
  runApp(MaterialApp(
    home: AllNews(),
  ));
}
