import 'package:flutter/material.dart';
import 'package:news_app/services/api_client.dart';

class AllNews extends StatefulWidget {
  const AllNews({Key? key}) : super(key: key);

  @override
  State<AllNews> createState() => _AllNewsState();
}

class _AllNewsState extends State<AllNews> {
  ApiClient _apiClient = ApiClient();
  List<dynamic> news = [];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    //  _callNews();
  }

  _callNews() async {
    news = await _apiClient.getNews();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Text('News App')),
        //body: ,
        body: FutureBuilder(
          future: _apiClient.getNews(),
          builder: (ctx, AsyncSnapshot<List<dynamic>> snapshot) {
            if (snapshot.hasError) {
              return Center(child: Text('Something Went Wrong...'));
            } else if (!snapshot.hasData) {
              return Center(child: CircularProgressIndicator());
            } else {
              return ListView.builder(
                  itemCount: snapshot.data?.length,
                  itemBuilder: (_, int index) {
                    return ListTile(
                      leading: Image.network((snapshot.data![index]
                              ['urlToImage']) ??
                          "http://cdn.onlinewebfonts.com/svg/img_98811.png"),
                      title: Text((snapshot.data![index]['content']) ?? ""),
                      subtitle:
                          Text((snapshot.data![index]['description']) ?? ""),
                    );
                  });
            }
          },
        ));
  }
}
