import 'package:dio/dio.dart';

class ApiClient {
  Dio _dio = Dio();
  Future<List<dynamic>> getNews() async {
    String URL =
        "https://newsapi.org/v2/top-headlines?country=us&apiKey=11f0dc28d8874be0bb82287cbcf26121";
    Response response = await _dio.get(URL);
    return response.data['articles'];
  }
}
