import 'package:flutter/material.dart';
import 'package:reactive_forms_example/pages/register.dart';

void main() {
  runApp(MaterialApp(home: Register()));
}
