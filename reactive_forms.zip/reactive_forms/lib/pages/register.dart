import 'package:flutter/material.dart';
import 'package:reactive_forms/reactive_forms.dart';

class Register extends StatefulWidget {
  const Register({Key? key}) : super(key: key);

  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  // 1st Step - Create Model
  late FormGroup form;
  @override
  initState() {
    super.initState();
    _createModel();
  }

  _createModel() {
    form = FormGroup({
      'email': FormControl<String>(
          touched: true,
          value: '',
          validators: [Validators.required, Validators.email]),
      'password': FormControl<String>(
          value: '', validators: [Validators.required, _isValidPassword])
    });
  }

  Map<String, dynamic>? _isValidPassword(AbstractControl<dynamic> ctrl) {
    String val = ctrl.value.toString();
    if (val.length >= 8 && val.length <= 25) {
      return null; // No Error
    } else {
      return {"invalidpwd": "Invalid Password"};
    }
  }

  _submitForm() {
    if (form.valid) {
      // Store the data in some object
      // and then either store in offline , Online store.
    } else {
      // form is invalid
      form.markAllAsTouched();
    }
  }

  @override
  Widget build(BuildContext context) {
    return ReactiveFormConfig(
      validationMessages: {
        ValidationMessage.required: (err) => "Field can't be empty"
      },
      child: Scaffold(
          appBar: AppBar(title: Text('Reactive Form')),
          body: ReactiveForm(
            formGroup: form,
            child: Column(children: [
              ReactiveTextField(
                //showErrors: (FormControl<String> ctrl) =>
                //  ctrl.invalid && ctrl.dirty,
                validationMessages: {
                  ValidationMessage.required: (err) => "Email is Required",
                  ValidationMessage.email: (err) => "Invalid Email"
                },
                formControlName: 'email',
                decoration: InputDecoration(
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10)),
                    labelText: "Email",
                    hintText: "Type Email here"),
              ),
              ReactiveTextField(
                obscureText: true,
                formControlName: 'password',
                validationMessages: {
                  "invalidpwd": (err) => "Password is Invalid"
                },
                decoration: InputDecoration(
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10)),
                    labelText: "Password",
                    hintText: "Type Password here"),
              ),
              ElevatedButton(
                  onPressed: () {
                    _submitForm();
                  },
                  child: Text('Submit'))
            ]),
          )),
    );
  }
}
