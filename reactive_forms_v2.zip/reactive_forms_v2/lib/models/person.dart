class Person {
  late String email;
  late String password;
  Person() {}
  Person.takeInput({required this.email, required this.password});
  @override
  String toString() {
    // TODO: implement toString
    return "Email " + email + " Password " + password;
  }

  // Serialization
  Map<String, dynamic> toJSON() {
    return {"email": email, "password": password};
  }

  // DeSerialization
  static fromJSON(Map<String, dynamic> map) {
    Person p = Person.takeInput(email: map['email'], password: map['password']);
    return p;
  }
}
