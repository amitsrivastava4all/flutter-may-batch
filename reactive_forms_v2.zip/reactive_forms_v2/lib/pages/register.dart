import 'package:flutter/material.dart';
import 'package:reactive_forms/reactive_forms.dart';
import 'package:reactive_forms_example/models/person.dart';

class Register extends StatefulWidget {
  const Register({Key? key}) : super(key: key);

  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  // 1st Step - Create Model
  late FormGroup form;

  // Create the Object of Person Model
  Person _person = Person();
  @override
  initState() {
    super.initState();
    _createModel();
  }

  _createModel() {
    form = FormGroup({
      'email': FormControl<String>(
          touched: true,
          value: '',
          asyncValidators: [_isDupEmail],
          validators: [Validators.required, Validators.email]),
      'password': FormControl<String>(
          value: '', validators: [Validators.required, _isValidPassword]),
      'address': FormArray([])
    });
  }

  List<String> emails = ["amit@yahoo.com", "ram@yahoo.com"];
  Future<Map<String, dynamic>?> _isDupEmail(
      AbstractControl<dynamic> ctrl) async {
    String emailValue = ctrl.value.toString();
    await Future.delayed(Duration(seconds: 5));
    return emails.contains(emailValue) ? {"dupemail": "Duplicate email"} : null;
  }

  Map<String, dynamic>? _isValidPassword(AbstractControl<dynamic> ctrl) {
    String val = ctrl.value.toString();
    if (val.length >= 8 && val.length <= 25) {
      return null; // No Error
    } else {
      return {"invalidpwd": "Invalid Password"};
    }
  }

  _addAddress() {
    FormArray fm = form.control('address') as FormArray;
    fm.add(FormGroup({
      'city': FormControl(value: '', validators: [Validators.required]),
      'country': FormControl(value: '', validators: [Validators.required])
    }));
  }

  _submitForm() {
    if (form.valid) {
      String email = form.control('email').value;
      String pwd = form.control('password').value;
      _person.email = email;
      _person.password = pwd;
      print("Person Object is $_person");
      print("JSON is ${_person.toJSON()}");
      // Store the data in some object
      // and then either store in offline , Online store.
    } else {
      // form is invalid
      form.markAllAsTouched();
    }
  }

  @override
  Widget build(BuildContext context) {
    return ReactiveFormConfig(
      validationMessages: {
        ValidationMessage.required: (err) => "Field can't be empty"
      },
      child: Scaffold(
          appBar: AppBar(title: Text('Reactive Form')),
          body: SingleChildScrollView(
            child: ReactiveForm(
              formGroup: form,
              child: Column(children: [
                ReactiveTextField(
                  //showErrors: (FormControl<String> ctrl) =>
                  //  ctrl.invalid && ctrl.dirty,
                  validationMessages: {
                    'dupemail': (err) => "Email is Duplicate ",
                    ValidationMessage.required: (err) => "Email is Required",
                    ValidationMessage.email: (err) => "Invalid Email"
                  },
                  formControlName: 'email',
                  decoration: InputDecoration(
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      labelText: "Email",
                      hintText: "Type Email here"),
                ),
                ReactiveTextField(
                  obscureText: true,
                  formControlName: 'password',
                  validationMessages: {
                    "invalidpwd": (err) => "Password is Invalid"
                  },
                  decoration: InputDecoration(
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      labelText: "Password",
                      hintText: "Type Password here"),
                ),
                ElevatedButton(
                    onPressed: () {
                      _addAddress();
                      //_submitForm();
                    },
                    child: Text('Add Address')),

                // Dynamic Fields
                ReactiveFormArray(
                    formArrayName: 'address',
                    builder: (context, FormArray formArr, Widget? child) {
                      FormArray addressList =
                          form.control('address') as FormArray;
                      List<Widget> list = addressList.controls
                          .map((control) => control as FormGroup)
                          .map((currentForm) {
                        return ReactiveForm(
                          formGroup: currentForm,
                          child: Column(
                            children: [
                              ReactiveTextField(
                                formControlName: 'city',
                                validationMessages: {
                                  ValidationMessage.required: (err) =>
                                      "City Can't Be Blank",
                                },
                                decoration: InputDecoration(
                                    labelText: 'City',
                                    border: OutlineInputBorder(
                                        borderRadius:
                                            BorderRadius.circular(10))),
                              ),
                              ReactiveTextField(
                                  formControlName: 'country',
                                  validationMessages: {
                                    ValidationMessage.required: (err) =>
                                        "Country Can't Be Blank",
                                  },
                                  decoration: InputDecoration(
                                      labelText: 'Country',
                                      border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(10))))
                            ],
                          ),
                        );
                      }).toList();
                      return Wrap(children: list);
                    }),

                ElevatedButton(
                    onPressed: () {
                      _submitForm();
                    },
                    child: Text('Submit'))
              ]),
            ),
          )),
    );
  }
}
