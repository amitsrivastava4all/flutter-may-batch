import 'package:firstapp/widgets/header.dart';
import 'package:firstapp/widgets/item.dart';
import 'package:flutter/material.dart';
import '../widgets/header.dart';

class FirstScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      appBar: PreferredSize(
        child: Header(
          title: "MyApp",
        ),
        preferredSize: Size.fromHeight(100),
      ),
    );
  }
}
