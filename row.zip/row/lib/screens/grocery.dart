import 'package:firstapp/widgets/header.dart';
import 'package:firstapp/widgets/itemrow.dart';
import 'package:flutter/material.dart';

import '../widgets/item.dart';

class Grocery extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.grey.shade300,
        appBar: PreferredSize(
          child: Header(
            title: "Fruit and Vegetable",
            color: Colors.pink,
          ),
          preferredSize: Size.fromHeight(70),
        ),
        body: Container(
          child: Column(children: [ItemRow(), ItemRow(), ItemRow()]),
        )
        //body: ,
        );
  }
}
