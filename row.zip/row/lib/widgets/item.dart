import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class Item extends StatelessWidget {
  double width;
  double height;
  Item({this.width = 100, this.height = 100});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Image.network(
          'https://www.cupitfood.com/wp-content/uploads/2018/08/wholesale-apples-1200x1200.png'),
      margin: EdgeInsets.all(40),
      width: width,
      height: height,
      decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [BoxShadow(color: Colors.black, blurRadius: 5)]),
    );
  }
}
