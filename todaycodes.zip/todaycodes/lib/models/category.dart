import 'package:flutter/material.dart';

class CategoryModel {
  String name;
  IconData icon;
  CategoryModel(this.name, this.icon);
}
