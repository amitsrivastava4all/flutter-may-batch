class Item {
  String image;
  String name;
  Item(this.image, this.name);
}
