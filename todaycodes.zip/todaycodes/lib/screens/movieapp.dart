import 'package:flutter/material.dart';
import 'package:secondapp/utils/constants.dart';
import 'package:secondapp/widgets/banner.dart' as moviebanner;
import 'package:secondapp/widgets/category.dart';
import 'package:secondapp/widgets/itemdisplay.dart';
import 'package:secondapp/widgets/movieappbar.dart';

class MovieApp extends StatelessWidget {
  const MovieApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        child: MovieAppBar(),
        preferredSize: Size.fromHeight(80),
      ),
      body: SingleChildScrollView(
        child: Container(
          //color: Colors.yellowAccent,
          child: Column(
            children: [
              Category(),
              moviebanner.Banner(),
              ItemDisplay(Constants.MOVIE),
              SizedBox(
                height: 40,
              ),
              ItemDisplay(Constants.EVENT)
            ],
          ),
        ),
      ),
    );
  }
}
