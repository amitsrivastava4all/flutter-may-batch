import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class Stack2 extends StatelessWidget {
  const Stack2({Key? key}) : super(key: key);

  _getContainer(
      {double width = 100, double height = 100, Color color = Colors.red}) {
    return Container(
      width: width,
      height: height,
      color: color,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Stack(
        fit: StackFit.expand,
        //fit: StackFit.loose,
        children: [
          Positioned(
              top: 10,
              right: 20,
              width: 100,
              height: 100,
              child:
                  _getContainer(width: 300, height: 300, color: Colors.green)),
          Positioned(
              top: 100,
              right: 50,
              width: 50,
              height: 50,
              child:
                  _getContainer(width: 200, height: 200, color: Colors.yellow)),
          Positioned(
              bottom: 100,
              left: 30,
              width: 100,
              height: 100,
              child: _getContainer()),
          Positioned(
              bottom: 100,
              right: 50,
              child: Icon(
                Icons.phone,
                color: Colors.red,
                size: 50,
              ))
        ],
      )),
    );
  }
}
