import 'package:flutter/material.dart';
import 'package:secondapp/models/category.dart';

class CategoryOperation {
  CategoryOperation._() {}
  static List<CategoryModel> getCategories() {
    return [
      CategoryModel("Movies", Icons.movie),
      CategoryModel("Streams", Icons.stream),
      CategoryModel("Music", Icons.music_note),
      CategoryModel("Sports", Icons.sports),
      CategoryModel("Events", Icons.event),
      CategoryModel("Plays", Icons.play_arrow),
      CategoryModel("Activites", Icons.local_activity)
    ];
    // return [
    //   "Movies",
    //   "Streams",
    //   "Music",
    //   "Sports",
    //   "Events",
    //   "Plays",
    //   "Activites"
    // ];
  }
}
