import 'package:secondapp/models/item.dart';
import 'package:secondapp/utils/constants.dart';

class ItemOperation {
  ItemOperation._() {} // Private Named Constructor
  static List<Item> getItems(int type) {
    if (type == Constants.MOVIE) {
      return [
        Item(
            "https://i0.wp.com/fanaticbuff.com/wp-content/uploads/2021/02/9-1-3.jpg",
            "KGF"),
        Item(
            "https://www.pinkvilla.com/files/styles/amp_metadata_content_image_min_696px_wide/public/_rrr_postponed.jpg",
            "RRR"),
        Item(
            "https://m.media-amazon.com/images/M/MV5BNTlmNDMzOWQtYzg4Ny00OWQ0LWFhN2MtNmQ2MDczZGZhNTU5XkEyXkFqcGdeQXVyODE5NzE3OTE@._V1_.jpg",
            "WAR"),
        Item(
            "https://www.pinkvilla.com/files/styles/amp_metadata_content_image_min_696px_wide/public/_rrr_postponed.jpg",
            "RRR"),
        Item(
            "https://i0.wp.com/fanaticbuff.com/wp-content/uploads/2021/02/9-1-3.jpg",
            "KGF")
      ];
    } else if (type == Constants.EVENT) {
      return [
        Item(
            "https://www.cricwindow.com/images/ipl/photo-gallary/mumbai-indians-winner-2020.jpg",
            "IPL"),
        Item(
            "https://www.techrounder.com/wp-content/uploads/2021/03/fifa-game-21.jpg",
            "FootBall"),
        Item(
            "http://www.fih.ch/ImageGen.ashx?width=581&constrain=true&compression=50&image=/media/12499937/wc-news.jpg",
            "Hockey")
      ];
    } else {
      return [];
    }
  }
}
