class Constants {
  static final int MOVIE = 1;
  static final int EVENT = 2;
}
