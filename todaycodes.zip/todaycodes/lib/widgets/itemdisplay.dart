import 'package:flutter/material.dart';
import 'package:secondapp/services/items.dart';
import 'package:secondapp/utils/constants.dart';

import '../models/item.dart';

class ItemDisplay extends StatelessWidget {
  int type;
  ItemDisplay(this.type);

  @override
  Widget build(BuildContext context) {
    Size deviceSize = MediaQuery.of(context).size;
    List<Item> items = ItemOperation.getItems(type);
    return Container(
      margin: EdgeInsets.all(10),
      height: deviceSize.height * 0.35,
      child: ListView.builder(
        physics: BouncingScrollPhysics(),
        scrollDirection: Axis.horizontal,
        itemBuilder: (_, int index) {
          return Container(
            width: deviceSize.width * 0.50,
            margin: EdgeInsets.all(5),
            decoration: BoxDecoration(
                border: Border.all(color: Colors.red, width: 2),
                borderRadius: BorderRadius.circular(10),
                image: DecorationImage(
                    image: NetworkImage(
                      items[index].image,
                    ),
                    fit: BoxFit.cover)),

            //child: Text('Hi'),
            child: Image.network(items[index].image),
          );
        },
        itemCount: items.length,
      ),
    );
  }
}
