import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class Stack2 extends StatelessWidget {
  const Stack2({Key? key}) : super(key: key);

  _getContainer(
      {double width = 100, double height = 100, Color color = Colors.red}) {
    return Container(
      width: width,
      height: height,
      color: color,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Stack(
        children: [
          _getContainer(width: 300, height: 300, color: Colors.green),
          _getContainer(width: 200, height: 200, color: Colors.yellow),
          _getContainer()
        ],
      )),
    );
  }
}
