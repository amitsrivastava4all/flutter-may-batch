import 'package:flutter/material.dart';
import 'package:secondapp/screens/movieapp.dart';
import 'package:secondapp/screens/stack2.dart';
import 'package:secondapp/screens/stackdemo.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: MovieApp(),
  ));
}
