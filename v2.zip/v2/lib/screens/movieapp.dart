import 'package:flutter/material.dart';
import 'package:secondapp/widgets/banner.dart' as moviebanner;
import 'package:secondapp/widgets/category.dart';
import 'package:secondapp/widgets/movieappbar.dart';

class MovieApp extends StatelessWidget {
  const MovieApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        child: MovieAppBar(),
        preferredSize: Size.fromHeight(80),
      ),
      body: Container(
        //color: Colors.yellowAccent,
        child: Column(
          children: [Category(), moviebanner.Banner()],
        ),
      ),
    );
  }
}
