import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class Banner extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size deviceSize = MediaQuery.of(context).size;
    return Container(
        height: deviceSize.height * 0.30,
        width: deviceSize.width,
        child: Stack(
          fit: StackFit.expand,
          children: [
            Container(
              color: Colors.amber,
              child: Image.network(
                  'https://upload.wikimedia.org/wikipedia/en/3/37/Mortal_Kombat_%282021_film%29.png',
                  fit: BoxFit.fill),
            ),
            Positioned(
                top: 30,
                left: 10,
                child: Text(
                  'Action\nMovie',
                  style: TextStyle(color: Colors.white, fontSize: 30),
                )),
            Positioned(
                bottom: 30,
                left: 10,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.movie,
                      color: Colors.white,
                    ),
                    ElevatedButton(
                        style: ButtonStyle(
                            backgroundColor:
                                MaterialStateProperty.all(Colors.pink)),
                        onPressed: () {},
                        child: Text('Buy or Rent'))
                  ],
                ))
          ],
        ));
  }
}
