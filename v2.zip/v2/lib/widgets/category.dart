import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:secondapp/models/category.dart';
import 'package:secondapp/services/categories.dart';

class Category extends StatelessWidget {
  const Category({Key? key}) : super(key: key);

  _showCategory(CategoryModel model) {
    return Container(
      margin: EdgeInsets.all(10),
      padding: EdgeInsets.all(5),
      child: Column(
        children: [Icon(model.icon), Text(model.name)],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    List<CategoryModel> categories = CategoryOperation.getCategories();
    return Container(
      height: 100,
      width: 400,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        // item builder is used to build the item
        itemBuilder: (_, int index) {
          //return Text(categories[index]);
          return _showCategory(categories[index]);
        },
        itemCount: CategoryOperation.getCategories()
            .length, // how many times items will be build (Length time)
      ),
    );
  }
}
