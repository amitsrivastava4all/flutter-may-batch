import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class MovieAppBar extends StatelessWidget {
  const MovieAppBar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 30),
          child: Icon(
            Icons.search,
            color: Colors.white,
          ),
        )
      ],
      title: Column(
        //mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'It All Start Here',
            style: TextStyle(fontSize: 30, color: Colors.white),
          ),
          Row(
            children: [
              Text(
                'New Delhi',
                style: TextStyle(color: Colors.white),
              ),
              Icon(
                Icons.arrow_forward_sharp,
                color: Colors.white,
              )
            ],
          )
        ],
      ),
      elevation: 0,
      backgroundColor: Color.fromARGB(255, 12, 12, 141),
    );
  }
}
