import 'package:flutter/material.dart';
import 'package:weather_app/pages/weather_page.dart';

// ?lat={lat}&lon={lon}&appid={API key}
void main() {
  runApp(MaterialApp(
    home: WeatherPage(),
  ));
}
