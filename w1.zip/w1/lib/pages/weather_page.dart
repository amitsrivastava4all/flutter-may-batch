import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:weather_app/utils/toast_message.dart';

class WeatherPage extends StatefulWidget {
  const WeatherPage({Key? key}) : super(key: key);

  @override
  State<WeatherPage> createState() => _WeatherPageState();
}

class _WeatherPageState extends State<WeatherPage> {
  _getGPS() async {
    // Service Enabled
    bool isEnabled = await Geolocator.isLocationServiceEnabled();
    if (!isEnabled) {
      // Message
      showToastMessage("GPS Service is Disabled....");
    }
    // Permission
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      LocationPermission per = await Geolocator.requestPermission();
      if (per == LocationPermission.denied) {
        showToastMessage("GPS Permission is Denied....");
      } else if (per == LocationPermission.deniedForever) {
        showToastMessage("GPS Permission is Denied ForEver....");
      }
    }
    Position pos = await Geolocator.getCurrentPosition();
    double lat = pos.latitude;
    double lng = pos.longitude;
    showToastMessage("Lat $lat and Lng $lng");
    // Lat and Lng
    // Call the Open Weather API
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Get Weather Details')),
      body: Column(children: [
        ElevatedButton(
            onPressed: () {
              _getGPS();
            },
            child: Text('Get GPS'))
      ]),
    );
  }
}
