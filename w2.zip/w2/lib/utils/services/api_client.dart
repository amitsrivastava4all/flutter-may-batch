import 'package:dio/dio.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

class ApiClient {
  Dio dio = Dio();
  getWeatherData(double lat, double lng) async {
    /*
    api.openweathermap.org/data/2.5/forecast?lat={lat}&lon={lon}&appid={API key}
    https://api.openweathermap.org/data/2.5/forecast?lat=37.4219985&lon=-122.0839999&appid=fb0ff3d08635a95f0dc185063406fb54
    */

    String URL = dotenv.env['URL']!;
    String APIKEY = dotenv.env['API_KEY']!;
    String endpoint = URL + "?lat=$lat&lon=$lng&appid=$APIKEY";
    print("End Point URL $endpoint");
    Response response = await dio.get(endpoint);
    print(response.data['list']);
    print(response.runtimeType);
  }
}
